import React, { useState } from 'react';

function NotesInput({ addNote }) {
    const [title, setTitle] = useState("");
    const [body, setBody] = useState("");
    const [charLimit, setCharLimit] = useState(50);

    const handleSubmit = (e) => {
        e.preventDefault();
        if (title && body) {
            addNote({
                id: +new Date(),
                title,
                body,
                archived: false,
                createdAt: new Date().toISOString(),
            });
            setTitle("");
            setBody("");
            setCharLimit(50);
        }
    };

    const handleTitleChange = (e) => {
        const value = e.target.value;
        if (value.length <= 50) {
            setTitle(value);
            setCharLimit(50 - value.length);
        }
    };

    return (
        <form onSubmit={handleSubmit}>
            <input
                type="text"
                value={title}
                onChange={handleTitleChange}
                placeholder="Judul Catatan"
                required
            />
            <small>{charLimit} karakter tersisa</small>
            <textarea
                value={body}
                onChange={(e) => setBody(e.target.value)}
                placeholder="Isi Catatan"
                required
            />
            <button type="submit">Tambah Catatan</button>
        </form>
    );
}

export default NotesInput;
