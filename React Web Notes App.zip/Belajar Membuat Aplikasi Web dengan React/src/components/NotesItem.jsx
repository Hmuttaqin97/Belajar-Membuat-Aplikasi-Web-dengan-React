import React from 'react';

function NotesItem({ note, deleteNote }) {
    return (
        <div className="note-item">
            <h3>{note.title}</h3>
            <p>{note.body}</p>
            <button onClick={() => deleteNote(note.id)}>Hapus</button>
        </div>
    );
}

export default NotesItem;
