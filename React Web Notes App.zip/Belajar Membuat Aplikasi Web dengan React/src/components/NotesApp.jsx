import React, { useState } from 'react';
import NavBar from './NavBar.jsx';
import NotesInput from './NotesInput.jsx';
import NotesList from './NotesList.jsx';
import SearchBar from './SearchBar.jsx';
import { getInitialData } from '../utils/index.js'; //Tambahkan ini

function NotesApp() {
	const [notes, setNotes] = useState(getInitialData); //Di dalam useState gunakan getInitialData

    const [searchQuery, setSearchQuery] = useState("");

    const addNote = (note) => {
        setNotes([...notes, note]);
    };

    const deleteNote = (id) => {
        setNotes(notes.filter(note => note.id !== id));
    };

    const filteredNotes = notes.filter(note =>
        note.title.toLowerCase().includes(searchQuery.toLowerCase())
    );

    return (
        <div className="container">
            <NavBar />
            <SearchBar setSearchQuery={setSearchQuery} />
            <NotesInput addNote={addNote} />
            <NotesList notes={filteredNotes} deleteNote={deleteNote} />
        </div>
    );
}

export default NotesApp;
