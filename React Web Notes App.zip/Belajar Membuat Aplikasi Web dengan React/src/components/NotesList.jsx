import React from 'react';
import NotesItem from './NotesItem.jsx';

function NotesList({ notes, deleteNote }) {
    if (notes.length === 0) {
        return <p className="empty-message">Tidak ada catatan</p>;
    }

    return (
        <div>
            {notes.map(note => (
                <NotesItem key={note.id} note={note} deleteNote={deleteNote} />
            ))}
        </div>
    );
}

export default NotesList;
