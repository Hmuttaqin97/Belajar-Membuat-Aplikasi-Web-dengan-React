import React from 'react';

function NavBar() {
    return (
        <nav>
            <h1>Aplikasi Catatan Pribadi</h1>
        </nav>
    );
}

export default NavBar;
