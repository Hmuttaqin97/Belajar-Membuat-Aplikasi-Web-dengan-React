import React from 'react';
import ReactDOM from 'react-dom';
import NotesApp from './NotesApp.jsx';

ReactDOM.render(<NotesApp />, document.getElementById('root'));
